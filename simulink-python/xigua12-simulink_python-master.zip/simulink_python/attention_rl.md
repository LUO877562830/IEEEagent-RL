1.[Reinforcement Learning in Multidimensional Environments Relies on Attention Mechanisms](<https://www.jneurosci.org/content/35/21/8145?utm_source=TrendMD&utm_medium=cpc&utm_campaign=JNeurosci_TrendMD_1>)

2.[Reinforcement Learning with Attention that Works: A Self-Supervised Approach](Reinforcement Learning with Attention that Works: A Self-Supervised Approach)

3.[VMAV-C: A Deep Attention-based Reinforcement Learning Algorithm for Model-based Control](<https://arxiv.org/abs/1812.09968>)

4.[Attention and Reinforcement Learning:Constructing Representations from Indirect Feedback](<http://matt.colorado.edu/papers/cogsci10cj.pdf>)

5.[Better deep visual attention with reinforcement learning in action recognition](<https://ieeexplore.ieee.org/document/8050638>)

6.[Attention-based Deep Reinforcement Learningfor Multi-view Environments](<http://www.ifaamas.org/Proceedings/aamas2019/pdfs/p1805.pdf>)

7.[Recurrent Models of Visual Attention](<https://papers.nips.cc/paper/5542-recurrent-models-of-visual-attention.pdf>)

